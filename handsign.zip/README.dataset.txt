# HAGRID-YOLO > HAGRID-YOLO-ONLYHAND
https://universe.roboflow.com/humanoffice/hagrid-yolo

Provided by a Roboflow user
License: CC BY 4.0

